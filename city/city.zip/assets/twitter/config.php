<?php
// The tokens, keys and secrets from the app you created at https://dev.twitter.com/apps

$config = array(
		'username' => "XXX", //username
		'limit' => 3, //how many tweets we would like to display?
		'with_replies' => true, //show replies? true or false
		'oauth_access_token' => 'TOKEN',
		'oauth_access_token_secret' => 'TOKEN_SECRET',
		'consumer_key' => 'KEY',
		'consumer_secret' => 'KEY_SECRET',
		'cache' => true
);

